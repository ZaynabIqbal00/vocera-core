import { VoceraApp } from '@/components/vocera-app'

export default function Page() {
  return <VoceraApp />
}
