'use client'

import { useState } from 'react'
import { Activity, AudioLines, Bell, ChevronDown, Headphones, Search, Settings2, ShieldCheck, Users, type LucideIcon } from 'lucide-react'
import { AnimatePresence, motion } from 'framer-motion'
import { AnalyticsScreen } from './vocera/analytics'
import { LiveCallScreen } from './vocera/live-call'
import { ReviewsScreen } from './vocera/reviews'
import { SettingsScreen } from './vocera/settings'
import { VoiceprintsScreen } from './vocera/voiceprints'
import type { CallScenario, ConsoleScreen } from './vocera/types'

type NavItem = { id: ConsoleScreen; label: string; caption: string; icon: LucideIcon }
const navItems: NavItem[] = [
  {id:'live',label:'Live call',caption:'Verification console',icon:AudioLines},
  {id:'voiceprints',label:'Voiceprints',caption:'Customer enrollment',icon:Users},
  {id:'reviews',label:'Review queue',caption:'Supervisor decisions',icon:ShieldCheck},
  {id:'analytics',label:'Analytics & audit',caption:'Performance insights',icon:Activity},
  {id:'settings',label:'Settings',caption:'Security policy',icon:Settings2},
]
const scenarioLabels: Record<CallScenario,string> = {genuine:'Genuine customer',cloned:'Cloned voice',different:'Different person'}

export function VoceraApp() {
  const [screen,setScreen] = useState<ConsoleScreen>('live')
  const [scenario,setScenario] = useState<CallScenario>('genuine')
  const [matchThreshold,setMatchThreshold] = useState(80)
  const [spoofThreshold,setSpoofThreshold] = useState(70)
  const [searchOpen,setSearchOpen] = useState(false)
  const activeItem = navItems.find((item)=>item.id===screen) ?? navItems[0]
  const ScreenIcon = activeItem.icon
  const renderScreen = () => {
    if (screen==='live') return <LiveCallScreen scenario={scenario} setScenario={setScenario} matchThreshold={matchThreshold} spoofThreshold={spoofThreshold}/>
    if (screen==='voiceprints') return <VoiceprintsScreen/>
    if (screen==='reviews') return <ReviewsScreen/>
    if (screen==='analytics') return <AnalyticsScreen/>
    return <SettingsScreen matchThreshold={matchThreshold} setMatchThreshold={setMatchThreshold} spoofThreshold={spoofThreshold} setSpoofThreshold={setSpoofThreshold}/>
  }
  return <main className="vocera-shell"><div className="ambient-glow glow-one"/><div className="ambient-glow glow-two"/><div className="ambient-glow glow-three"/><div className="grain-overlay"/>
    <div className="console-app">
      <header className="console-header"><button className="brand-lockup" onClick={()=>setScreen('live')} aria-label="Vocera live call console"><span className="brand-icon"><AudioLines size={17}/></span><span>vocera<span>.</span></span></button><div className="header-divider"/><div className="bank-name"><span className="bank-mark">DB</span><span><b>Demo Bank</b><small>VOICE SECURITY</small></span></div><div className="header-spacer"/>
        <div className="demo-switcher"><span className="demo-label">SIMULATION</span><div className="scenario-desktop">{(Object.keys(scenarioLabels) as CallScenario[]).map((item)=><button key={item} className={scenario===item?'scenario-active':''} onClick={()=>setScenario(item)}>{scenarioLabels[item]}</button>)}</div><select className="scenario-mobile" value={scenario} onChange={(event)=>setScenario(event.target.value as CallScenario)} aria-label="Choose demo call scenario">{(Object.keys(scenarioLabels) as CallScenario[]).map((item)=><option key={item} value={item}>{scenarioLabels[item]}</option>)}</select></div>
        <div className={`top-search ${searchOpen?'search-open':''}`}><Search size={15}/><input placeholder="Search calls, customers…" aria-label="Search calls and customers"/><kbd>⌘ K</kbd></div><button className="header-icon-button notification-button" aria-label="Notifications"><Bell size={17}/><i/></button><div className="agent-menu"><span className="agent-initials">HR</span><span className="agent-name"><b>Hassan Raza</b><small><i/>On shift · Karachi</small></span><ChevronDown size={14}/></div><button className="mobile-search-button" onClick={()=>setSearchOpen(!searchOpen)} aria-label="Toggle search"><Search size={17}/></button>
      </header>
      <aside className="console-sidebar"><div className="sidebar-label">WORKSPACE</div><nav aria-label="Staff workspace navigation">{navItems.map(({id,label,caption,icon:Icon})=><button key={id} className={`sidebar-link ${screen===id?'sidebar-link-active':''}`} onClick={()=>setScreen(id)} aria-current={screen===id?'page':undefined}><span className="sidebar-icon"><Icon size={17}/></span><span className="sidebar-link-copy"><b>{label}</b><small>{caption}</small></span>{id==='reviews'&&<span className="nav-count">3</span>}{screen===id&&<i className="sidebar-active-mark"/>}</button>)}</nav><div className="sidebar-spacer"/><div className="sidebar-status"><div className="status-orb"><Headphones size={16}/></div><div><b>Voice pipeline</b><small><i/>All systems operational</small></div></div><div className="sidebar-foot">VOCERA INTERNAL CONSOLE <span>v1.4.0 · DEMO</span></div></aside>
      <section className="console-main"><div className="content-topline"><div className="breadcrumb"><span>Workspace</span><span>/</span><b><ScreenIcon size={13}/>{activeItem.label}</b></div><div className="shift-status"><span className="shift-dot"/>LIVE SHIFT <span className="shift-divider"/><span className="shift-extra">22 NOV 2026</span><span className="shift-divider"/><span className="shift-extra">KHI</span></div></div><div className="screen-content" key={screen}><AnimatePresence mode="wait"><motion.div key={screen} className="screen-motion" initial={{opacity:0,y:9}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-5}} transition={{duration:.22}}>{renderScreen()}</motion.div></AnimatePresence></div><footer className="console-footer"><span>DEMO BANK · INTERNAL USE ONLY</span><span>VOICE BIOMETRIC DECISION SUPPORT <i/> CUSTOMER-FACING APP: NO</span></footer></section>
      <nav className="mobile-nav" aria-label="Staff workspace navigation">{navItems.map(({id,label,icon:Icon})=><button key={id} className={screen===id?'mobile-nav-active':''} onClick={()=>setScreen(id)} aria-current={screen===id?'page':undefined}><Icon size={17}/><span>{label==='Analytics & audit'?'Analytics':label==='Review queue'?'Review':label==='Voiceprints'?'Voices':label==='Settings'?'Settings':'Live'}</span>{id==='reviews'&&<i className="mobile-nav-count"/>}</button>)}</nav>
    </div>
  </main>
}
