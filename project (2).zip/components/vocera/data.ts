import type { Caller } from './types'

export const callers: Caller[] = [
  { id: 'VC-29041', name: 'Ayesha Khan', account: 'PK36 •••• 4821', phone: '+92 300 ••• 2190', time: '10:42:18', spoof: 98, match: 96, reason: 'Routine verification', outcome: 'Verified', amount: 'PKR 85,000' },
  { id: 'VC-29038', name: 'Unknown caller', account: 'PK17 •••• 9104', phone: '+92 321 ••• 6712', time: '10:38:02', spoof: 12, match: 96, reason: 'Spoof suspicion', outcome: 'Rejected', amount: 'PKR 240,000' },
  { id: 'VC-29021', name: 'Bilal Ahmed', account: 'PK08 •••• 7735', phone: '+92 333 ••• 4018', time: '10:21:46', spoof: 97, match: 72, reason: 'Low speaker match', outcome: 'Review', amount: 'PKR 48,500' },
  { id: 'VC-28956', name: 'Sara Malik', account: 'PK66 •••• 1482', phone: '+92 301 ••• 5306', time: '09:56:11', spoof: 99, match: 94, reason: 'Noisy audio', outcome: 'Review', amount: 'PKR 125,000' },
  { id: 'VC-28931', name: 'Usman Qureshi', account: 'PK21 •••• 6603', phone: '+92 312 ••• 8872', time: '09:31:05', spoof: 96, match: 91, reason: 'Low confidence', outcome: 'Verified', amount: 'PKR 32,000' },
]

export const customers = [
  { initials: 'AK', name: 'Ayesha Khan', account: 'PK36 •••• 4821', status: 'Enrolled', last: 'Today, 10:42 AM', quality: 96, hue: 'lilac' },
  { initials: 'BA', name: 'Bilal Ahmed', account: 'PK08 •••• 7735', status: 'Enrolled', last: 'Today, 10:21 AM', quality: 91, hue: 'rose' },
  { initials: 'SM', name: 'Sara Malik', account: 'PK66 •••• 1482', status: 'Pending', last: 'Yesterday, 4:18 PM', quality: 68, hue: 'blue' },
  { initials: 'UQ', name: 'Usman Qureshi', account: 'PK21 •••• 6603', status: 'Expired', last: '12 Jun, 11:03 AM', quality: 0, hue: 'gold' },
  { initials: 'FN', name: 'Fatima Noor', account: 'PK42 •••• 1956', status: 'Enrolled', last: 'Yesterday, 2:51 PM', quality: 94, hue: 'mint' },
]

export const matchTrend = [
  { day: 'Mon', match: 91, spoof: 8 }, { day: 'Tue', match: 94, spoof: 12 },
  { day: 'Wed', match: 89, spoof: 16 }, { day: 'Thu', match: 96, spoof: 10 },
  { day: 'Fri', match: 93, spoof: 21 }, { day: 'Sat', match: 97, spoof: 13 },
  { day: 'Sun', match: 95, spoof: 9 },
]

export const hourlySpoofs = [
  { hour: '08', count: 2 }, { hour: '09', count: 5 }, { hour: '10', count: 3 },
  { hour: '11', count: 8 }, { hour: '12', count: 4 }, { hour: '13', count: 11 },
  { hour: '14', count: 6 }, { hour: '15', count: 9 }, { hour: '16', count: 4 },
]
