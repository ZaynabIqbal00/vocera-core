'use client'

import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Activity, ArrowRight, AudioLines, Check, CircleHelp, Clock3, Headphones, LockKeyhole, Mic, Phone, ShieldAlert, ShieldCheck, Sparkles, UserRound, X } from 'lucide-react'
import { AudioOrb, Panel, StatusTag, Waveform } from './primitives'
import type { CallScenario } from './types'

type LiveCallProps = { scenario: CallScenario; setScenario: (scenario: CallScenario) => void; matchThreshold: number; spoofThreshold: number }

export function LiveCallScreen({ scenario, setScenario, matchThreshold, spoofThreshold }: LiveCallProps) {
  const [checking, setChecking] = useState(false)
  const [stage, setStage] = useState(0)
  const [seconds, setSeconds] = useState(42)
  const [notice, setNotice] = useState('')
  useEffect(() => {
    if (!checking) return
    const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000)
    const secondStage = window.setTimeout(() => setStage(2), 1000)
    const finalStage = window.setTimeout(() => setStage(3), 1900)
    return () => { window.clearInterval(timer); window.clearTimeout(secondStage); window.clearTimeout(finalStage) }
  }, [checking, scenario])
  const result = useMemo(() => scenario === 'cloned'
    ? { spoof: 18, match: 96 }
    : scenario === 'different' ? { spoof: 96, match: 42 } : { spoof: 98, match: 96 }, [scenario])
  const decision = stage < 3 ? null : result.spoof < spoofThreshold ? 'Rejected' : result.match < matchThreshold ? 'Review' : 'Verified'
  const outcomeCopy = decision === 'Rejected' ? 'Rejected: suspected synthetic or replayed voice' : decision === 'Review' ? 'Unknown caller: send to human review' : 'Verified — voiceprint matched'
  const time = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`
  const runCheck = () => {
    if (checking) { setChecking(false); setStage(0); return }
    setNotice(''); setSeconds(42); setStage(1); setChecking(true)
  }
  const handleAction = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(''), 4200) }

  return <div className="live-layout">
    <div className="live-main-column">
      <div className="call-overview-row"><div className="section-eyebrow"><span className="live-pulse"/>INCOMING CALL · VC-29041</div><StatusTag outcome="Active">CALL CONNECTED</StatusTag></div>
      <Panel className="caller-card"><div className="caller-card-main"><div className="caller-avatar caller-avatar-large">AK</div><div className="caller-identity"><span className="mini-label">REGISTERED CUSTOMER</span><h2>Ayesha Khan</h2><p>PK36 •••• 4821 <span>·</span> {time}</p></div><StatusTag outcome="Enrolled">VOICEPRINT ENROLLED</StatusTag></div><div className="caller-card-meta"><span><Phone size={14}/> +92 300 ••• 2190</span><span><Clock3 size={14}/> {time} <small>call time</small></span><span><LockKeyhole size={14}/> Secure session</span></div></Panel>

      <Panel className="voice-stage"><div className="voice-stage-top"><div><div className="section-eyebrow">LIVE VOICE ANALYSIS</div><p>Ask the caller to say their verification phrase.</p></div><span className="voice-stage-lock"><LockKeyhole size={13}/>Private analysis</span></div><AudioOrb live={checking}/><div className="orb-caption"><span className={`live-pulse ${checking ? '' : 'idle'}`}/>{checking ? 'Listening to caller' : 'Ready when you are'}</div><Waveform active={checking}/><div className="check-prompt"><span className="quote-mark">“</span><span>My voice confirms my identity.</span><span className="phrase-duration">Required phrase</span></div><button className={`record-control ${checking ? 'record-control-active' : ''}`} onClick={runCheck} aria-label={checking ? 'Stop voice check' : 'Start voice check'}><span>{checking ? <AudioLines size={22}/> : <Mic size={22}/>}</span><small>{checking ? 'STOP CHECK' : 'START VOICE CHECK'}</small></button><div className="privacy-caption"><LockKeyhole size={12}/> Customer&apos;s PIN and CNIC are not used for this decision.</div></Panel>

      <div className="call-action-row">{decision === 'Verified' && <button className="button-primary" onClick={() => handleAction('Request cleared. Continue with the customer request.')}><Check size={15}/>Proceed with request</button>}{decision !== 'Rejected' && <button className="button-secondary" onClick={() => handleAction('OTP fallback sent to the registered number ending 2190.')}><Phone size={15}/>Request OTP / MFA fallback</button>}<button className="button-secondary" onClick={() => handleAction('Supervisor Hassan Raza has been notified.')}><ArrowRight size={15}/>Escalate to supervisor</button>{decision === 'Rejected' && <button className="button-danger" onClick={() => handleAction('Call ended. Account flagged for fraud review.')}><ShieldAlert size={15}/>End call and flag account</button>}{!decision && <button className="button-secondary" onClick={() => handleAction('Call ended by Hassan Raza.')}><X size={15}/>End call</button>}</div>
      <AnimatePresence>{notice && <motion.div className="inline-notice" role="status" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><Check size={15}/>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss"><X size={14}/></button></motion.div>}</AnimatePresence>
      <div className="pipeline-foot"><Sparkles size={13}/>Pipeline: ECAPA-TDNN speaker embeddings + AASIST anti-spoofing</div>
    </div>

    <aside className="analysis-column" aria-label="Voice verification results"><div className="analysis-heading"><div><div className="section-eyebrow">VERIFICATION SIGNAL</div><h2>Trust signals</h2></div><span className="stage-count">{stage === 0 ? 'WAITING' : stage === 1 ? '01 / 03' : stage === 2 ? '02 / 03' : 'COMPLETE'}</span></div>
      <div className={`signal-card ${stage >= 1 ? 'signal-ready' : ''}`}><div className="signal-top"><span className="signal-icon purple"><AudioLines size={16}/></span><span><b>Anti-spoofing check</b><small>AASIST live inference</small></span><strong>{stage >= 1 ? `${result.spoof}%` : '—'}</strong></div><div className="score-track"><i className={stage >= 1 && result.spoof < spoofThreshold ? 'bar-rejected' : ''} style={{ width: stage >= 1 ? `${result.spoof}%` : '3%' }}/><b className="score-threshold" style={{ left: `${spoofThreshold}%` }}/></div><div className="signal-foot"><span>{stage >= 1 ? result.spoof >= spoofThreshold ? 'Bonafide audio signal' : 'Spoof risk detected' : 'Waiting for voice signal'}</span><span>PASS ≥ {spoofThreshold}%</span></div></div>
      <div className={`signal-card ${stage >= 2 ? 'signal-ready' : ''}`}><div className="signal-top"><span className="signal-icon pink"><Activity size={16}/></span><span><b>Speaker match</b><small>Cosine similarity to enrolled print</small></span><strong>{stage >= 2 ? `${result.match}%` : '—'}</strong></div><div className="score-track match-track"><i className={stage >= 2 && result.match < matchThreshold ? 'bar-warning' : ''} style={{ width: stage >= 2 ? `${result.match}%` : '3%' }}/><b className="score-threshold" style={{ left: `${matchThreshold}%` }}/></div><div className="signal-foot"><span>{stage >= 2 ? result.match >= matchThreshold ? 'Voiceprint match confident' : 'Below identity threshold' : 'Comparing encrypted voiceprint'}</span><span>PASS ≥ {matchThreshold}%</span></div></div>
      <AnimatePresence mode="wait"><motion.div key={decision ?? 'pending'} className={`decision-card ${decision ? `decision-${decision.toLowerCase()}` : ''}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}><div className="decision-card-top"><span className="decision-icon">{decision === 'Verified' ? <Check size={17}/> : decision === 'Rejected' ? <ShieldAlert size={17}/> : decision === 'Review' ? <CircleHelp size={17}/> : <Headphones size={17}/>}</span><span className="mini-label">FINAL DECISION</span></div><h3>{decision ? outcomeCopy : 'Awaiting voice check'}</h3><p>{decision === 'Verified' ? 'Both required signals cleared the bank threshold.' : decision === 'Rejected' ? 'Anti-spoofing failed. Do not continue the request.' : decision === 'Review' ? 'Identity confidence is below threshold. Confirm with a supervisor.' : 'The caller is not scored until you start a voice check.'}</p><StatusTag outcome={decision ?? 'Open'}>{decision ?? 'READY'}</StatusTag></motion.div></AnimatePresence>
      <div className="cascade-note"><span className="cascade-line"/><p><b>Decision cascade</b><br/>Spoof fail → reject. Spoof pass + match pass → verify. Otherwise → human review.</p></div>
    </aside>
  </div>
}
