'use client'

import type { ReactNode } from 'react'
import { motion } from 'framer-motion'
import { AudioLines, Check, ShieldCheck } from 'lucide-react'
import type { Outcome } from './types'

export function Panel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`console-panel ${className}`}>{children}</section>
}

export function SectionHeading({ eyebrow, title, copy, action }: { eyebrow: string; title: ReactNode; copy?: string; action?: ReactNode }) {
  return <div className="section-heading"><div><div className="section-eyebrow"><i />{eyebrow}</div><h1>{title}</h1>{copy && <p>{copy}</p>}</div>{action && <div className="section-action">{action}</div>}</div>
}

export function StatusTag({ outcome, children }: { outcome: Outcome | 'Enrolled' | 'Pending' | 'Expired' | 'Active' | 'Open' | 'Resolved'; children?: ReactNode }) {
  const kind = outcome === 'Verified' || outcome === 'Enrolled' || outcome === 'Active' || outcome === 'Resolved' ? 'positive' : outcome === 'Rejected' || outcome === 'Expired' ? 'negative' : outcome === 'Review' || outcome === 'Pending' ? 'warning' : 'neutral'
  return <span className={`status-tag ${kind}`}><i />{children ?? outcome}</span>
}

export function Avatar({ initials, tone = 'lilac' }: { initials: string; tone?: string }) {
  return <span className={`customer-avatar tone-${tone}`}>{initials}</span>
}

export function AudioOrb({ live = false }: { live?: boolean }) {
  return <motion.div className={`audio-orb ${live ? 'audio-orb-live' : ''}`} animate={live ? { scale: [1, 1.045, 1], rotate: [0, 2, 0] } : {}} transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }} aria-label={live ? 'Voice analysis active' : 'Audio visualizer'} role="img"><span className="orb-shine"/><span className="orb-rim"/><span className="orb-core"><AudioLines size={26}/></span></motion.div>
}

export function Waveform({ active = false, compact = false }: { active?: boolean; compact?: boolean }) {
  return <div className={`wave-ribbon ${active ? 'wave-ribbon-active' : ''} ${compact ? 'wave-ribbon-compact' : ''}`} aria-label={active ? 'Voice signal detected' : 'Audio waveform'} role="img">{Array.from({ length: compact ? 35 : 57 }, (_, index) => <i key={index} style={{ '--bar-height': `${12 + ((index * 37 + index * index * 7) % 76)}%`, '--bar-delay': `${index * 15}ms` } as React.CSSProperties}/>)}</div>
}

export function PhraseCard({ index, phrase, done, active }: { index: number; phrase: string; done: boolean; active: boolean }) {
  return <div className={`phrase-card ${done ? 'phrase-captured' : ''} ${active ? 'phrase-active' : ''}`}><span className="phrase-check">{done ? <Check size={14}/> : `0${index + 1}`}</span><span className="phrase-text">{phrase}</span><span className="phrase-status">{done ? 'CAPTURED' : active ? 'LISTENING' : 'READY'}</span></div>
}

export function DecisionIcon({ outcome }: { outcome: Outcome }) {
  return <span className={`decision-icon ${outcome.toLowerCase()}`}>{outcome === 'Verified' ? <ShieldCheck size={16}/> : <i/>}</span>
}
