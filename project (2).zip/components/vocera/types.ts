export type ConsoleScreen = 'live' | 'voiceprints' | 'reviews' | 'analytics' | 'settings'
export type CallScenario = 'genuine' | 'cloned' | 'different'
export type Outcome = 'Verified' | 'Review' | 'Rejected'

export type Caller = {
  id: string
  name: string
  account: string
  phone: string
  time: string
  spoof: number
  match: number
  reason: string
  outcome: Outcome
  amount: string
}
