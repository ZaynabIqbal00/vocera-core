'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { AudioLines, Check, ChevronRight, Headphones, LockKeyhole, Mic, RotateCcw, Search, ShieldCheck, UserPlus, X } from 'lucide-react'
import { Avatar, Panel, PhraseCard, SectionHeading, StatusTag, Waveform } from './primitives'
import { customers } from './data'

const enrollmentPhrases = ['My voice confirms my identity.', 'I authorize this secure request.', 'Today is a good day to bank securely.']
type CustomerStatus = 'Enrolled' | 'Pending' | 'Expired'

export function VoiceprintsScreen() {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<(typeof customers)[number]>(customers[2])
  const [statusFilter, setStatusFilter] = useState('All statuses')
  const [search, setSearch] = useState('')
  const [consent, setConsent] = useState(false)
  const [captured, setCaptured] = useState(0)
  const [recording, setRecording] = useState(false)
  const [success, setSuccess] = useState(false)
  const [statusOverrides, setStatusOverrides] = useState<Record<string, CustomerStatus>>({})
  const visibleCustomers = customers.filter((customer) => {
    const status = statusOverrides[customer.name] ?? customer.status
    const matchesSearch = `${customer.name} ${customer.account}`.toLowerCase().includes(search.toLowerCase())
    return matchesSearch && (statusFilter === 'All statuses' || status === statusFilter)
  })
  const selectedStatus = statusOverrides[selectedCustomer.name] ?? selectedCustomer.status as CustomerStatus
  const capturePhrase = () => {
    if (recording || !consent || success) return
    setRecording(true)
    window.setTimeout(() => {
      setRecording(false)
      const next = Math.min(captured + 1, enrollmentPhrases.length)
      setCaptured(next)
      if (next === enrollmentPhrases.length) setSuccess(true)
    }, 850)
  }
  const finishEnrollment = () => {
    setStatusOverrides((current) => ({ ...current, [selectedCustomer.name]: 'Enrolled' }))
    setDrawerOpen(false)
    setSuccess(false)
    setConsent(false)
    setCaptured(0)
  }
  const revokeVoiceprint = () => {
    setStatusOverrides((current) => ({ ...current, [selectedCustomer.name]: 'Expired' }))
    setDrawerOpen(false)
    setConsent(false)
    setCaptured(0)
  }
  const openEnrollment = (customer = customers.find((entry) => entry.status === 'Pending') ?? customers[0]) => {
    setSelectedCustomer(customer)
    setConsent(false)
    setCaptured(0)
    setSuccess(false)
    setDrawerOpen(true)
  }

  return <div className="page-stack">
    <SectionHeading eyebrow="CUSTOMER BIOMETRICS" title={<>Customer <em>voiceprints</em></>} copy="Manage enrollment status and voiceprint quality. Raw voice data stays protected." action={<button className="button-primary" onClick={() => openEnrollment()}><UserPlus size={15}/>Enroll customer</button>}/>
    <div className="table-toolbar"><div className="search-field"><Search size={15}/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search customer or account" aria-label="Search customers"/></div><select className="filter-button" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label="Filter enrollment status"><option>All statuses</option><option>Enrolled</option><option>Pending</option><option>Expired</option></select><span className="result-count">{visibleCustomers.length} customers</span></div>
    <Panel className="customer-list-panel"><div className="customer-list-header"><span>CUSTOMER</span><span>ENROLLMENT</span><span>LAST VERIFIED</span><span>VOICE QUALITY</span><span/></div><div className="customer-list">{visibleCustomers.map((customer) => { const status = statusOverrides[customer.name] ?? customer.status as CustomerStatus; return <div className="customer-row" key={customer.account}><div className="customer-name-cell"><Avatar initials={customer.initials} tone={customer.hue}/><div><b>{customer.name}</b><small>{customer.account}</small></div></div><div className="customer-status-cell"><StatusTag outcome={status}/></div><span className="customer-last">{customer.last}</span><div className="quality-cell"><div className="quality-value">{customer.quality ? `${customer.quality}%` : '—'}</div><div className="quality-track"><i style={{width:`${customer.quality}%`}}/></div></div><button className="round-arrow" aria-label={`Open ${customer.name} voiceprint`} onClick={() => openEnrollment(customer)}><ChevronRight size={15}/></button></div>})}</div></Panel>
    <div className="voiceprint-note"><ShieldCheck size={15}/><span><b>Privacy by design.</b> Agents see confidence scores and decisions only, never raw voice recordings or biometrics.</span><LockKeyhole size={14}/></div>

    <AnimatePresence>{drawerOpen && <motion.div className="drawer-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={(event) => {if (event.target === event.currentTarget) setDrawerOpen(false)}}><motion.section className="enroll-drawer" role="dialog" aria-modal="true" aria-labelledby="enroll-title" initial={{x:'100%'}} animate={{x:0}} exit={{x:'100%'}} transition={{type:'spring',damping:28,stiffness:250}}><div className="drawer-header"><div><div className="section-eyebrow">VOICEPRINT SETUP</div><h2 id="enroll-title">Enroll customer</h2></div><button className="icon-button" onClick={() => setDrawerOpen(false)} aria-label="Close enrollment"><X size={18}/></button></div>{success ? <div className="enroll-success"><span className="success-seal"><Check size={26}/></span><span className="section-eyebrow">ENROLLMENT COMPLETE</span><h3>Voiceprint created</h3><p>{selectedCustomer.name}&apos;s voiceprint is ready for secure call verification.</p><div className="success-quality"><span>Voiceprint quality</span><b>96 / 100 · Excellent</b></div><button className="button-primary full-width" onClick={finishEnrollment}>Done</button><button className="text-action" onClick={() => {setSuccess(false);setCaptured(0);setConsent(false)}}><RotateCcw size={13}/>Re-enroll voiceprint</button></div> : <><div className="enroll-customer-summary"><Avatar initials={selectedCustomer.initials} tone={selectedCustomer.hue}/><div><b>{selectedCustomer.name}</b><small>{selectedCustomer.account} · Customer since 2019</small></div><StatusTag outcome={selectedStatus as CustomerStatus}/></div><label className="consent-check"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)}/><span><b>Customer consent confirmed</b><small>Verbal consent to voice biometric enrollment has been recorded.</small></span></label><div className="drawer-section-title"><span>Required phrases</span><small>{captured} / 3 captured</small></div><div className="drawer-phrases">{enrollmentPhrases.map((phrase,index) => <PhraseCard key={phrase} index={index} phrase={phrase} done={captured>index} active={recording && captured===index}/>)}</div><div className="wave-preview-label"><span><AudioLines size={14}/>Live capture preview</span><span>{recording ? 'RECORDING' : 'READY'}</span></div><Panel className="drawer-wave"><Waveform active={recording} compact/><div className="quality-meter-label"><span>Signal quality</span><b>{recording ? 'Analyzing…' : captured ? '96 / 100 · Excellent' : 'Awaiting sample'}</b></div><div className="quality-track"><i style={{width:captured?'96%':'12%'}}/></div></Panel><button className={`record-button ${recording?'recording':''}`} onClick={capturePhrase} disabled={!consent || recording || captured>=3}><span>{recording?<AudioLines size={18}/>:<Mic size={18}/>}</span>{recording?'Capturing phrase…':captured>=3?'All phrases captured':'Capture next phrase'}</button><p className="drawer-hint"><Headphones size={13}/>Record in a quiet space. Never ask for a PIN or CNIC.</p><button className="button-primary full-width" disabled={captured<3} onClick={() => setSuccess(true)}>Create voiceprint <ChevronRight size={15}/></button>{selectedStatus === 'Enrolled' && <button className="button-danger full-width" onClick={revokeVoiceprint}>Revoke voiceprint</button>}</>}</motion.section></motion.div>}</AnimatePresence>
  </div>
}
